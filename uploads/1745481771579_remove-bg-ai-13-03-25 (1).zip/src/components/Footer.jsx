import React, { useEffect, useState } from 'react';
import axios from 'axios'; // For API calls

const Footer = () => {
  const [footerData, setFooterData] = useState(null);
  const [loading, setLoading] = useState(true);
  
  
  // Fetch header data on component mount
  useEffect(() => {
    const fetchFooterData = async () => {
      try {
        const res = await axios.get('http://localhost:3000/footers'); // adjust your backend URL here
        if (res.data.success) {
          setFooterData(res.data.data[0]); // Assuming you want the first header
        }
      } catch (err) {
        console.error('Error fetching header data:', err);
      } finally {
        setLoading(false);
      }
    };
   
fetchFooterData();
  }, []);

  if (loading) {
    return <div>Loading...</div>; // Or a spinner
  }

  if (!footerData) {
    return <div>No header data found</div>;
  }

  console.log(footerData.socialMedia.map((socialItem,index) => {
    console.log(socialItem.link);
    console.log(index);
  }));
  return (
    <footer className="footer-wapper">
      <div className="footer-top">
        <div className="container w-1240">
          <div className="footer-top-row">
            <div className="footer-top-left">
              <h2>Get Updates</h2>
              <p>Sign up for our mailing list and we will let you know when we release new features or updates.</p>
            </div>
            <div className="footer-top-right">
              <input
                type="email"
                placeholder="your email address"
              
              />
              <button >Subscribe</button>
            </div>
          </div>
        </div>
      </div>

      <div className="footer-center">
        <div className="container w-1240">
          <div className="row">
            <div className="col-lg-3 col-md-6">
              <div className="footer-center-item">
                <div className="footer-logo">
                  <a href="#"><span>{footerData.logoText}</span></a>
                </div>

                <div className="footer-social-media">
                  <h3>Social Media</h3>
                  <ul>
                  {footerData.socialMedia.map((socialItem) => (
                      <li key={socialItem.id}>
                        <a href={socialItem.link}>
                       <img src={`http://localhost:3000/socialMedia/${socialItem.image}`} style={{width:'100%'}} alt="Facebook" />
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="footer-center-item">
                <div className="footer-center-title">
                  <h3>Tools & API</h3>
                  <ul>
                  {footerData.toolsAPI.map((toolItem) => (
                      <li key={toolItem.id}>
                        <a href={toolItem.url}>{toolItem.title}</a>
                      </li>
                    ))}
                    
                  </ul>
                </div>
                <div className="footer-center-title">
                  <h3>Company</h3>
                  <ul>
                  {footerData.companyLinks.map((companyItem) => (
                      <li key={companyItem.id}>
                        <a href={companyItem.url}>{companyItem.title}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="footer-center-item">
                <div className="footer-center-title">
                  <h3>How To Use</h3>
                  <ul>
                  {footerData.howToUse.map((howToUseItem) => (
                      <li key={howToUseItem.id}>
                        <a href={howToUseItem.url}>{howToUseItem.title}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="footer-center-item">
                <div className="footer-center-title">
                  <h3>Support</h3>
                  <ul>
                  {footerData.support.map((supportItem) => (
                      <li key={supportItem.id}>
                        <a href={supportItem.url}>{supportItem.title}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>{footerData.copyright}</p>
      </div>
    </footer>
  );
};

export default Footer;
