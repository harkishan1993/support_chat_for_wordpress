import React from 'react';

const Testimonials = () => {
  return (
    <section className="testimonials">
      <div className="container w-1240">
        <div className="testimonials-heading">
          <h5>TESTIMONIALS?</h5>
          <h2>From startups to established brands, you'll be in good company.</h2>
        </div>
        <div className="owl-carousel owl-theme owl-testimonials">
          {/* Testimonial 1 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 2 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 3 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 4 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 5 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 6 */}
          <div className="item">
            <div className="owl-testimonials-col">
              <div className="owl-testimonials-items">
                <div className="owl-testimonials-text">
                  <p>
                    Well I'm particularly surprised at how accurate and smooth are the cut-out edges. I always
                    wanted a super fast background remover. Finally, I do not have to open up Photoshop to get
                    the job done.
                  </p>
                </div>
                <div className="owl-testimonials-bottom">
                  <div className="owl-testimonials-img">
                    <img src="img/speakers5-1.png" alt="" />
                  </div>
                  <div className="owl-testimonials-bottom-text">
                    <h4>
                      <a href="#">Andrea Mangano</a>
                    </h4>
                    <p>Product Designer - assemble.tv</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
