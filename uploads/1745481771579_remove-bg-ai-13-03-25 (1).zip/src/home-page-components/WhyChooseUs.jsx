import React from 'react';

const WhyChooseUs = () => {
  return (
    <section className="why-choose-us">
      <div className="container w-1240">
        <div className="why-choose-us-heading">
          <h5>WHY CHOOSE US?</h5>
          <h2>Amazing image quality for various scenarios</h2>
          <p>
            Create designs with our background remover tool. Turn your images into art, stunning banners,
            visual presentations, product catalog, and graphics—fully customizable for your needs.
          </p>
        </div>
        <div className="why-choose-d-tab-wrapper">
          <div className="why-choose-tab-menu">
            <ul>
              <li>
                <a href="javascript:void(0)" className="why-choose-tab-a why-choose-active-a" data-id="Products">
                  Products
                </a>
              </li>
              <li>
                <a href="javascript:void(0)" className="why-choose-tab-a" data-id="People">
                  People
                </a>
              </li>
              <li>
                <a href="javascript:void(0)" className="why-choose-tab-a" data-id="Cars">
                  Cars
                </a>
              </li>
              <li>
                <a href="javascript:void(0)" className="why-choose-tab-a" data-id="Animals">
                  Animals
                </a>
              </li>
              <li>
                <a href="javascript:void(0)" className="why-choose-tab-a" data-id="Graphics">
                  Graphics
                </a>
              </li>
            </ul>
          </div>
          <div className="why-choose-tab-container">
            <div className="why-choose-tab why-choose-tab-active" data-id="Products">
              <div className="why-choose-tab-img">
                <img src="img/why-choose-01.png" alt="Image" />
                <img src="img/why-choose-02.png" alt="Image" />
                <img src="img/why-choose-03.png" alt="Image" />
                <img src="img/why-choose-04.png" alt="Image" />
              </div>
            </div>
            <div className="why-choose-tab" data-id="People">
              <div className="why-choose-tab-img">
                <img src="img/why-choose-03.png" alt="Image" />
                <img src="img/why-choose-04.png" alt="Image" />
              </div>
            </div>
            <div className="why-choose-tab" data-id="Cars">
              <div className="why-choose-tab-img">
                <img src="img/why-choose-04.png" alt="Image" />
              </div>
            </div>
            <div className="why-choose-tab" data-id="Animals">
              <div className="why-choose-tab-img">
                <img src="img/why-choose-02.png" alt="Image" />
                <img src="img/why-choose-03.png" alt="Image" />
                <img src="img/why-choose-04.png" alt="Image" />
              </div>
            </div>
            <div className="why-choose-tab" data-id="Graphics">
              <div className="why-choose-tab-img">
                <img src="img/why-choose-01.png" alt="Image" />
                <img src="img/why-choose-02.png" alt="Image" />
                <img src="img/why-choose-03.png" alt="Image" />
                <img src="img/why-choose-04.png" alt="Image" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
