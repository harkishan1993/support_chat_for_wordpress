import React from 'react';

const HomeBanner = () => {
  return (
    <>
      <section className="banner-us">
        <div className="container w-1240">
          <div className="row">
            <div className="col-lg-6">
              <div className="banner-us-left">

                <div className="banner-us-heading">
                  <h1>AI Background Remover</h1>
                  <p>
                    Remove background from image instantly, fully automated and&nbsp;
                    <span>FREE</span>
                  </p>
                </div>

                <div className="banner-us-center">
                  <div className="banner-us-center-items">

                    <div className="banner-us-validation-file-upload">
                      <input type="file" id="fileID" />
                      <span>Choose File</span>
                      <img src="img/file-upload-icon.png" alt="file upload icon" />
                    </div>

                    <div className="banner-us-validation-file-text">
                      <p>
                        Or Drop an image, paste image with <b>Ctrl + V</b>
                      </p>
                    </div>

                  </div>
                </div>

                <div className="banner-us-bottom">

                  <div className="banner-us-bottom-text-image">
                    <div className="banner-us-bottom-text">
                      <p>No image? Try one of these</p>
                    </div>

                    <div className="banner-us-bottom-image">
                      <img src="img/animal_thumb.png" alt="animal thumb" />
                      <img src="img/human_thumb.png" alt="human thumb" />
                      <img src="img/car1_thumb.png" alt="car thumb" />
                      <img src="img/product_thumb.png" alt="product thumb" />
                    </div>
                  </div>

                  <p>
                    By uploading an image or URL you agree to our
                    <a href="#"> Terms of Service </a>. This site is protected by reCaptcha and its
                    <a href="#"> Privacy Policy </a> and
                    <a href="#"> Terms of Service </a> apply.
                  </p>

                </div>

              </div>
            </div>

            <div className="col-lg-6">
              <div id="banner-after-before-wrapper">

                <div id="banner-before">
                  <img
                    className="content-image"
                    src="img/314f99534e84b8aab56d808477cbb2e5.png"
                    draggable="false"
                    style={{ width: '817.5px' }}
                    alt="before"
                  />
                </div>

                <div id="banner-after">
                  <img
                    className="content-image"
                    src="img/30701b7169d5ba0b1f01dad0eb18bc2e.jpg"
                    draggable="false"
                    alt="after"
                  />
                </div>

                <div id="resizer">
                  <div className="banner-scroller">
                    <div className="banner-scroller-img">
                      {/* Add scroll handler or image here if needed */}
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>
    </>
  );
};

export default HomeBanner;
