import React from 'react';

const WhyChooseUsSecond = () => {
  return (
    <section className="why-choose-us">
      <div className="container w-1240">
        <div className="why-choose-us-heading">
          <h5>WHY CHOOSE US?</h5>
          <h2>Who is it made for?</h2>
          <p>
            Whether you’re a seasoned photographer, a creative graphic designer, an innovative marketer, or
            running a dynamic eCommerce store, Removal.AI will seamlessly adapt to your specific needs.
          </p>
        </div>
        <div className="expand-container">
          <div className="slide">
            <img className="expand-slide-img" src="img/01.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-01.png" alt="Image" />
                <h2>
                  <a href="#">Individuals</a>
                </h2>
              </div>
            </div>
          </div>
          <div className="slide">
            <img className="expand-slide-img" src="img/02.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-02.png" alt="Image" />
                <h2 className="ca-expand-title">
                  <a href="#">Photographers</a>
                </h2>
              </div>
            </div>
          </div>
          <div className="slide">
            <img className="expand-slide-img" src="img/03.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-03.png" alt="Image" />
                <h2 className="ca-expand-title">
                  <a href="#">Marketers</a>
                </h2>
              </div>
            </div>
          </div>
          <div className="slide">
            <img className="expand-slide-img" src="img/04.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-04.png" alt="Image" />
                <h2 className="ca-expand-title">
                  <a href="#">Developers</a>
                </h2>
              </div>
            </div>
          </div>
          <div className="slide">
            <img className="expand-slide-img" src="img/05.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-05.png" alt="Image" />
                <h2 className="ca-expand-title">
                  <a href="#">Ecommerce</a>
                </h2>
              </div>
            </div>
          </div>
          <div className="slide">
            <img className="expand-slide-img" src="img/06.jpg" alt="" />
            <div className="expand-slide-ic-box">
              <div className="expand-slide-ic-box-items">
                <img src="img/why-icon-06.png" alt="Image" />
                <h2 className="ca-expand-title">
                  <a href="#">Enterprise</a>
                </h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUsSecond;
